# Proyek 4: Dari Kampung Halaman ke Kampung Halaman

### Gambaran umum

- Pengantar
- Figma
- Gambar

**Pengantar**

Ini adalah proyek yang menampilkan kampung halaman beberapa karyawan Practicum. Kita telah membuatnya sehingga semua elemen ditampilkan secara tepat di ukuran layar yang populer. Kami sarankan untuk meluangkan lebih banyak waktu dalam menyelesaikan proyek ini, karena ini lebih sulit daripada proyek yang sebelumnya.

**Figma**

- [Tautkan ke proyek di Figma](https://www.figma.com/file/1zCYcflj6BJx5VqOvXU9nb/Sprint-3-From-Homeland-to-Homeland-desktop-mobile?node-id=0%3A1)

**Gambar**

Cara kamu melakukannya di tempat kerja adalah dengan mengekspor gambar langsung dari dari Figma — kami sarankan melakukan itu untuk berlatih lebih banyak. Jangan lupa untuk mengoptimalkannya [di sini] (https://tinypng.com/), sehingga proyek kamu dimuat lebih cepat.

Semoga berhasil dan bersenang-senanglah!

Jawa Barat, Indonesia

Aditya Wibowo
Peserta Practicum

Jawa Barat atau dikenal dengan Tatar Sunda adalah sebuah provinsi di Indonesia. Ibu kota provinsi ini berada di Kota Bandung. Pada tahun 2022 penduduk provinsi Jawa Barat berjumlah 49.405.808 jiwa, dengan kepadatan 1.379 jiwa/km2. Berdasarkan sensus BPS pada tahun 2010, penduduk di Jawa Barat merupakan provinsi dengan penduduk terbanyak pertama di Indonesia, penduduk aslinya merupakan suku Sunda.

Salah satu fakta yang istimewa dari provinsi Jawa Barat adalah angklung yang ditetapkan sebagai warisan budaya dunia. Angklung ditetapkan sebagai warisan budaya dunia oleh UNESCO (United Nations Educational, Scientific and Culture Organization) pada tahun 2010 di Kenya.
